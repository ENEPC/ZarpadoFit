# ZarpadoFit

TPO grupal para la materia Seminario de Integracion Profesional
1º cuatrimestre 2025 - UADE

# Integrantes

- 1175206 - Guerra Irizaga, Santiago Rafael
- 1148065 - Parrondo Bastos, Felipe
- 1148960 - Pascual, Lucas Mauricio
- 1171404 - Pérez Colman, Nicolás Alberto
- 1177428 - Rocca Mauro Alejandro
- 1174251 - Rodriguez Claros Adan Jorge

# Descripcion

ZarpadoFit es una aplicacion que permite ver como te queda una prenda de ropa usando inteligencia artificial
